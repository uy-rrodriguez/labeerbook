<div>
    <div class="row titre-contenu">Modification du statut</div>

    <form method="post" action="#">
        <div class="form-group">
            <label for="status">Comment allez-vous aujourd'hui ?</label>
            <input type="text" class="form-control" id="StatusEdit" name="status"/><br>
            <button type="button" onclick="editProfile()" class="btn btn-default">Submit</button>
        </div>
    </form>
</div>

