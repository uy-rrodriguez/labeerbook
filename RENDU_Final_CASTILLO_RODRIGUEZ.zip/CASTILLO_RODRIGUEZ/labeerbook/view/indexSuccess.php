<a href="./?action=login">Connectez vous !</a>
