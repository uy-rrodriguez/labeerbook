<?php
    /*//*//*/
		Auteur : Q.CASTILLO
	/*//*//*/
?>
Erreur dans la liste des amis.
