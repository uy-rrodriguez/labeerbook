<div id="login">
    <form method="post" action="./?action=login">
        <div class="form-group">
            <label for="login">Login :</label>
            <input type="text" class="form-control" name="login" autofocus/><br>

            <label for="password">Password :</label>
            <input type="password" class="form-control" name="password" /><br>

            <button type="submit" class="btn btn-default btn-lg">Se connecter</button>
        </div>
    </form>
</div>
