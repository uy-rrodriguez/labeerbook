<?php
	include($nameApp."/view/ajaxGetMessagesSuccess.php");
?>
