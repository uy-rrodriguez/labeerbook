Erreur lors de la recherche de tous les chats
