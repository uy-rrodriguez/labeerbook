<?php
    class config {
        const AVATAR_FOLDER = "upload/avatar";
    }
?>
